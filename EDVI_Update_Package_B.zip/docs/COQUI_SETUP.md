# COQUI / PIPER Offline TTS - Mobile Setup (brief)

1) Download a Coqui TTS small German model (from Coqui releases / mirror). Models are large (100-400MB). Use a stable Wi-Fi.
2) Place the model files into the app folder: Android/data/com.elitecompanion.app/files/coqui-model/
3) Grant the file access when the app asks for model installation.
4) In-app: Settings -> TTS -> Coqui: 'Install Model' -> point to the folder.
5) Once installed, app will use CoquiTtsAdapter.speak() to synthesize. If not present, fallback to Android TTS.
