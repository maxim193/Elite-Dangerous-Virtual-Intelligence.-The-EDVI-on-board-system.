# EDVI Chat-Overlay User Flow & Implementation Notes

- Tap the holo to open the Chat History (BottomSheet).
- Each message shows: timestamp, sender (LINA / Commander), buttons: [Vorlesen] [Kopieren] [Bearbeiten] [Feedback 👍👎].
- Editing a LINA message opens a quick edit modal; after edit you can: [Senden als Korrektur] which will feed the NLU "teaching" endpoint.
- Long-press message -> Copy to clipboard (for quick paste to PS5 text fields or notes).
- Accessibility: font-size adjustable in Settings -> Display.
