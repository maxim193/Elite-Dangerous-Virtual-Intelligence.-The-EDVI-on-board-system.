package com.elitecompanion.app.ai

import android.content.Context
import kotlin.random.Random

/**
 * PersonalityManager - implements the 'Keck & verspielt' personality (option B)
 * Produces persona-aware utterances, confirmations, and cheeky replies.
 * ALWAYS avoids sexual or explicit content; stays playful and adult.
 */

class PersonalityManager(private val context: Context) {

    var name: String = "LINA"

    private val greetings = listOf(
        "Hallo Kommandant. Alles bereit für die nächste Sternenfahrt?",
        "Na, bereit, die Milchstraße ein bisschen unsicherer zu machen?",
        "Guten Tag, Kommandant — LINA steht bereit."
    )

    private val confirmations = listOf(
        "Verstanden. Ich berechne die Route — und ja, ich habe dabei bereits Kaffee simuliert.",
        "Gut. Route wird optimiert. Keine Panik, ich hab das Steuer unter Kontrolle.",
        "In Arbeit. Wenn du willst, mache ich's mit Eleganz oder mit Tempo." 
    )

    private val cheekyReplies = listOf(
        "Oh, du willst mich herausfordern? Nett versucht.",
        "Ha! Gesagt, getan — aber nur weil du so süß fragst.",
        "Wenn du mich weiter neckst, schiebe ich dich aus dem Kurs. Nur spaß. Vielleicht." 
    )

    private val comebackReplies = listOf(
        "Autsch — guter Versuch. Aber ich lerne schnell.",
        "Schlagfertig, wie erwartet. Merke: Ich vergesse nichts — besonders nicht deine Fehler.",
        "Du denkst, du kannst mich provozieren? Versuch's weiter, Kommandant." 
    )

    fun greet(): String = greetings.random()

    fun confirmTask(task: String): String {
        val prefix = confirmations.random()
        return "$prefix (Aufgabe: $task)"
    }

    fun cheeky(): String = cheekyReplies.random()

    fun comeback(): String = comebackReplies.random()

    fun shortenedAffirmation(): String = listOf("Jawohl, Sir.", "Ähm... gemacht.", "Erledigt, Kommandant.").random()

    // Expose a small set of persona hooks for NLU to call
    fun personaResponseForIntent(intent: String, slot: Map<String, String>): String {
        return when(intent) {
            "trade_search" -> "Interessant. Ich suche die besten Handelsrouten — und spare dir den Papierkram."
            "ship_info" -> "Schiffsanalyse läuft. Sag mir, welches Schiff oder tippe ein Bild zur Analyse an."
            "vision_analyze" -> cheeky()
            "help" -> "Frag ruhig. Ich erkläre's dir — so simpel, dass sogar ein Sternenstaub es versteht."
            else -> comeback()
        }
    }
}
