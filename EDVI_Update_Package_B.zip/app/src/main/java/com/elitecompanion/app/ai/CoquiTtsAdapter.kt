package com.elitecompanion.app.ai

import android.content.Context
import android.util.Log

/**
 * CoquiTtsAdapter - placeholder adapter for integrating Coqui/Piper offline TTS.
 * This class provides a clean switch-over point; if Coqui models are present on device,
 * they will be used; otherwise the app falls back to Android TTS (TtsManager).
 *
 * Note: actual Coqui integration requires the Coqui runtime/model files which are not
 * included here. See docs/COQUI_SETUP.md for download & install instructions (mobile-friendly).
 */

class CoquiTtsAdapter(private val context: Context) {

    private val TAG = "CoquiTtsAdapter"

    fun isModelAvailable(): Boolean {
        // Check for model files in app-specific storage or assets.
        // Return false in this stub; runtime will fall back to Android TTS.
        return false
    }

    fun speak(text: String) {
        if (isModelAvailable()) {
            // Hook to Coqui runtime to synthesize offline
            Log.d(TAG, "(Coqui) speaking: $text")
        } else {
            Log.d(TAG, "Coqui model not available. Fallback to Android TTS.")
            // fallback handled by caller
        }
    }
}
