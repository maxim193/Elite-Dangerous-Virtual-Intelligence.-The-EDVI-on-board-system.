package com.elitecompanion.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elitecompanion.app.ai.PersonalityManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EDVIApp()
        }
    }
}

@Composable
fun EDVIApp() {
    val ctx = LocalContext.current
    val personality = remember { PersonalityManager(ctx) }
    var showChat by remember { mutableStateOf(false) }
    var lastUtterance by remember { mutableStateOf(personality.greet()) }

    Box(modifier = Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF071023), Color(0xFF0b1830)))
    )) {
        // Dashboard / cockpit base
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(40.dp))
            Text("EDVI — Onboard System", color = Color.White, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(16.dp))
            // Hologram projector area
            Box(modifier = Modifier
                .height(380.dp)
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color(0x11227733), shape = RoundedCornerShape(16.dp))
                .clickable { showChat = true }
            ) {
                // Hologram placeholder: stylized circle + pulse
                Box(modifier = Modifier.align(Alignment.Center)) {
                    Surface(modifier = Modifier.size(240.dp), color = Color(0x1100FFFF), shape = RoundedCornerShape(120.dp)) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(text = "LINA", color = Color(0xFFBEEBFF), fontSize = 28.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
                // Chat hint
                Text("Tippe hier, um die Konsole zu öffnen", color = Color(0x80FFFFFF), modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            // Controls
            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(onClick = {
                    lastUtterance = personality.confirmTask("Route durch das System")
                }) { Text("Route berechnen") }
                Button(onClick = { lastUtterance = personality.cheeky() }) { Text("Necken") }
                Button(onClick = { lastUtterance = personality.comeback() }) { Text("Kontern") }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(lastUtterance, color = Color(0xFFBEEBFF), modifier = Modifier.padding(12.dp))
        }

        if (showChat) {
            ChatOverlay(onClose = { showChat = false }, personality = personality)
        }
    }
}

@Composable
fun ChatOverlay(onClose: () -> Unit, personality: PersonalityManager) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xCC000814)) {
        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Konsole", color = Color.White, fontSize = 18.sp)
                Text("Schließen", color = Color.LightGray, modifier = Modifier.clickable { onClose() })
            }
            Spacer(modifier = Modifier.height(8.dp))
            // Chat content placeholder
            Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color(0x11000000), shape = RoundedCornerShape(8.dp)).padding(8.dp)) {
                Text("[Chat-Historie erscheint hier...]", color = Color.LightGray)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextField(value = "", onValueChange = {}, modifier = Modifier.weight(1f), placeholder = { Text("Eingeben...") })
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { /* send */ }) { Text("Senden") }
            }
        }
    }
}
