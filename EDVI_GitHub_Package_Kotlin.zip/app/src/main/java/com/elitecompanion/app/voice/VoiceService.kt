package com.elitecompanion.app.voice

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class VoiceService : Service() {
    private val TAG = "VoiceService"
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); Log.d(TAG, "VoiceService created (stub)") }
    override fun onDestroy() { super.onDestroy(); Log.d(TAG, "VoiceService destroyed") }
}
