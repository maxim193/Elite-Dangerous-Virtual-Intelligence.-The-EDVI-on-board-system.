package com.elitecompanion.app.ai

import android.content.Context

class PersonalityManager(private val context: Context) {
    var name: String = "LINA"
    private val greetings = listOf("Hallo Kommandant. Alles bereit für die nächste Sternenfahrt?","Na, bereit, die Milchstraße ein bisschen unsicherer zu machen?","Guten Tag, Kommandant — LINA steht bereit.")
    private val confirmations = listOf("Verstanden. Ich berechne die Route — und ja, ich habe dabei bereits Kaffee simuliert.","Gut. Route wird optimiert. Keine Panik, ich hab das Steuer unter Kontrolle.","In Arbeit. Wenn du willst, mache ich's mit Eleganz oder mit Tempo.")
    private val cheekyReplies = listOf("Oh, du willst mich herausfordern? Nett versucht.","Ha! Gesagt, getan — aber nur weil du so süß fragst.","Wenn du mich weiter neckst, schiebe ich dich aus dem Kurs. Nur spaß. Vielleicht.")
    private val comebackReplies = listOf("Autsch — guter Versuch. Aber ich lerne schnell.","Schlagfertig, wie erwartet. Merke: Ich vergesse nichts — besonders nicht deine Fehler.","Du denkst, du kannst mich provozieren? Versuch's weiter, Kommandant.")
    fun greet(): String = greetings.random()
    fun confirmTask(task: String): String { val prefix = confirmations.random(); return "$prefix (Aufgabe: $task)" }
    fun cheeky(): String = cheekyReplies.random()
    fun comeback(): String = comebackReplies.random()
}
