# EDVI — EDVI-Onboard-System (Kotlin scaffold)
This repo contains a minimal Kotlin Android project scaffold for EDVI (Elite Dangerous Virtual Intelligence).
Upload the `app/` folder contents into your GitHub repository to enable the GitHub Actions build (see .github/workflows).
